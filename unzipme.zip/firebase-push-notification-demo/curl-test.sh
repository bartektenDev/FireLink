#!/bin/bash
curl -X POST -H "Authorization: key=AAAA16-Iy60:APA91bHw6cYpz8coElaSpv_y4WeIlXq_BVeAJ65BJOm1nb2PVQV310BUN_Ng4mnMqftT7XbGTCGtwOrLSIhYQ1lhi7wAm24d5xOa1qYbRVQhX-JqxpODlL1GsHTzGMzcy01HMp__C3-v" -H "Content-Type: application/json" \
   -d '{
  "data": {
    "notification": {
        "title": "FCM Message",
        "body": "This is an FCM Message",
        "icon": "/itwonders-web-logo.png",
    }
  },
  "to": "e8QGA8v-DoY:APA91bG1oJHDp1aoE-YXFNc3L80W0LNnQirJkw0du3zs7vwKHj7fzJ6hzfHOHLnuO4Lg6XuLtvxNPCal6pMvc-TCVzFh7OFu2M_mlEi-Wfcinu_0jTPK1I653HK28j7vFOx7XEe4rJ9U"
}' https://fcm.googleapis.com/fcm/send
